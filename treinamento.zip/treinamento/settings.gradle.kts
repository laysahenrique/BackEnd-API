rootProject.name = "treinamento"
