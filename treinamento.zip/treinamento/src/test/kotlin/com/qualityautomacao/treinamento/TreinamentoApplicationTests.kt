package com.qualityautomacao.treinamento

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TreinamentoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
